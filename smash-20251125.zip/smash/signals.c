// signals.c
#include "signals.h"